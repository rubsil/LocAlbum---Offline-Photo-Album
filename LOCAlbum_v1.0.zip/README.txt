📸 LOCAlbum - Offline Photo Album
---------------------------------------------

🇵🇹 INSTRUÇÕES (PORTUGUÊS)
---------------------------------------------
Coloca aqui as tuas FOTOS e VÍDEOS.

Organiza tudo em pastas por ANO e MÊS, assim:
  2023\Janeiro
  2023\Fevereiro
  2024\Março
  2025\Julho

Também podes usar nomes de meses em INGLÊS:
  2024\January
  2024\February
  2024\March

💡 Dicas:
- Não uses acentos nem caracteres especiais nos nomes das pastas.
- Podes misturar fotos (.jpg, .png, .jpeg) e vídeos (.mp4, .mov, .webm).
- As imagens e vídeos dentro de cada pasta serão mostrados por ordem de data.

Quando terminares de adicionar novas fotos:
  👉 Executa o ficheiro "_1_update_album.bat" (na pasta principal)
  para atualizar o álbum automaticamente.

As tuas memórias ficarão organizadas e prontas a ver!

---------------------------------------------

🇬🇧 INSTRUCTIONS (ENGLISH)
---------------------------------------------
Place your PHOTOS and VIDEOS here.

Organize them in folders by YEAR and MONTH, like this:
  2023\January
  2023\February
  2024\March
  2025\July

You can also use month names in PORTUGUESE:
  2024\Janeiro
  2024\Fevereiro
  2024\Março

💡 Tips:
- Avoid accents or special characters in folder names.
- You can mix photos (.jpg, .png, .jpeg) and videos (.mp4, .mov, .webm).
- Files inside each folder will be shown in date order.

When you finish adding new photos:
  👉 Run "_1_update_album.bat" (in the main folder)
  to automatically update your album.

Your memories will stay beautifully organized — offline!

---------------------------------------------
LOCAlbum © 2025 - Rúben Silva
